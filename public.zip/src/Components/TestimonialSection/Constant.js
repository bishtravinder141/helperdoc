export const TESTIMONIAL = [
  {
    id: 1,
    name: "John Doe",
    content:
      "Lorem Ipsum is simply dummy text of printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text.",
    image: "image_5.png",
    occupation: "Web Developer",
    reviews: 5,
  },
  {
    id: 2,
    name: "Jane Smith",
    content:
      "Lorem Ipsum is simply dummy text of printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text.",
    image: "image_6.png",
    occupation: "Web Developer",
    reviews: 5,
  },
  {
    id: 3,
    name: "John Doe1",
    content:
      "Lorem Ipsum is simply dummy text of printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text.",
    image: "image_7.png",
    occupation: "Web Developer",
    reviews: 5,
  },
  {
    id: 4,
    name: "Jane Smith1",
    content:
      "Lorem Ipsum is simply dummy text of printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text.",
    image: "image_5.png",
    occupation: "Housewife",
    reviews: 5,
  },
];
