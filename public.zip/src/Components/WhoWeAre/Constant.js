export const WHO_WE_ARE = ["innovative", "flexible", "personal"];
