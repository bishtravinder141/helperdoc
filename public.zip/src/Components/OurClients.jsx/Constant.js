export const CLIENTS = [
  "google.svg",
  "amazon.svg",
  "slack.svg",
  "tyaalpha.svg",
  "dropbox.svg",
  "shangxi.svg",
];
