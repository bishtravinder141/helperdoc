export const JOB_TYPE = [
  {
    type: "full_time",
    value: "fullTime",
  },
  {
    type: "part_time",
    value: "partTime",
  },
];

export const SORT_BY = [
  {
    type: "newest",
    value: "newest",
  },
  {
    type: "oldest",
    value: "oldest",
  },
];
