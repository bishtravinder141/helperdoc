export const QUICK_LINKS = [
  { url: "/candidates", value: "find_jobs" },
  { url: "/candidates", value: "submit_resume" },
  { url: "/employees", value: "post_jobs" },
  { url: "/employees", value: "hire_candidates" },
  { url: "/help", value: "contact_support" },
  { url: "/help", value: "faqs" },
];

export const FOR_CANDIDATES = [
  { url: "/candidates", value: "find_jobs" },
  { url: "/candidates", value: "submit_resume" },
];

export const FOR_EMPLOYEE = [
  { url: "/employees", value: "post_jobs" },
  { url: "/employees", value: "hire_candidates" },
];

export const DOWNLOAD_APP = [
  { url: "/help", value: "contact_support" },
  { url: "/help", value: "faqs" },
];
