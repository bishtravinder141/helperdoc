import React, { useState } from "react";
import Autocomplete from "react-google-autocomplete";
import { googleSearchPlaceKey } from "../../Config/authConfig";

const LocationAutocomplete = ({
  onSelect,
  field,
  placeholder = "City or country",
  setValue
}) => {
  //  const {setValue} = useForm();
  const handlePlaceSelect = (place) => {
    if (place && place.geometry) {
      const lat = place.geometry.location.lat();
      const lng = place.geometry.location.lng();
      onSelect(place.formatted_address, { lat, lng });
    }
  };
  const handleOnBlur = () => {
  // setLocation({ location: searchedText, lat: null, long: null })
  setValue(field?.name,"");
  }
  return (
    <Autocomplete
      {...field}
      apiKey={googleSearchPlaceKey}
      onPlaceSelected={(place) => {
        field.onChange(place.formatted_address);
        handlePlaceSelect(place);
      }}
      onChange={(event) => field.onChange(event.target.value)}
      onBlur = {handleOnBlur}
      types={["(regions)"]}
      placeholder={placeholder}
      // componentRestrictions={{ country: "us" }} // Restrict results to a specific country if needed
    />
  );
};

export default LocationAutocomplete;
