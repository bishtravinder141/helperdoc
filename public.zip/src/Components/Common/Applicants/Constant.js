export const JOBS = [
    {
      title: "Hiroshi Nomura",
      age: "28",
      description: "Description for Job Title 1.",
      location: "Hong Kong",
      date: "From 27 Feb 2024",
      type: "Full Time",
      image: "image_5.png",
      jobrole: "DOMESTIC HELP",
      jobtitle: "Need a office boy",
      jobdescription: "Good day mam I'm interested to apply",
      application: "",
      conversation: "",
      status: "active",
    },
  ];