import React from 'react'
import PostJobNavigation from './PostJobNavigation'

export default function PostJobSteps() {
  return (
    <>
      Dummy
      {/* <PostJobNavigation/> */}
    </>
  )
}