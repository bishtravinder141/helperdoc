import React from 'react'

export default function PostJobStep1() {
  return (
    <div>PostJobStep1</div>
  )
}