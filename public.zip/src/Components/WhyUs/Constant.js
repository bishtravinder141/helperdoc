export const CHOICES = [
  {
    title: "Ipsum dolor sit amet consectetur adipiscing elit",
    content:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt labore et dolore.",
  },
  {
    title: "Ipsum dolor sit amet consectetur adipiscing elit",
    content:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt labore et dolore.",
  },
  {
    title: "Ipsum dolor sit amet consectetur adipiscing elit",
    content:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt labore et dolore.",
  },
];
