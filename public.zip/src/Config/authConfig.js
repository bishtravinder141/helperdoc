// Google captcha ID
export const googleCaptchaID = process.env.REACT_APP_RECAPTCHA_ID;

// Google place search ID
export const googleSearchPlaceKey = process.env.REACT_APP_GOOGLE_MAP_API;

// Admin whatsapp number
export const adminWhatsappNumber = process.env.REACT_APP_ADMIN_WHATSAPP_NUMBER;
