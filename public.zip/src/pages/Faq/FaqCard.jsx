import React from "react";
import { Accordion, AccordionDetails, AccordionSummary } from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";

const FaqCard = ({ curFaq}) => {
    const {question,answer,_id} = curFaq;
  return (
    <div className="faqAccord">
      <Accordion className="accordionlist">
        <AccordionSummary className="accordHead"
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1-content"
          id="panel1-header"
        >
          {question}
        </AccordionSummary>
        <AccordionDetails className="accordAns">{answer}</AccordionDetails>
      </Accordion>
    </div>
  );
};

export default FaqCard;