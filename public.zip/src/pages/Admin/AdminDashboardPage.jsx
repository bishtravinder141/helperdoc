import React from 'react'

const AdminDashboardPage = () => {
  return (
    <div>AdminDashboardPage</div>
  )
}

export default AdminDashboardPage