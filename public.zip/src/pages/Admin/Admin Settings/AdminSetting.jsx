import React, { useState } from "react";
import { yupResolver } from "@hookform/resolvers/yup";
import { Controller, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import * as yup from "yup";
import { Box } from "@mui/system";
import CustomTextField from "../../../Components/Common/InputFields/CustomTextField";
import {
  FormControl,
  FormLabel,
  IconButton,
  InputAdornment,
  MenuItem,
  Select,
  Button,
} from "@mui/material";
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import AdminHeaderSection from "../../../Components/Common/AdminHeaderSection";
import ErrorMessage from "../../../Components/Common/ErrorMessage/ErrorMessage";
import {
  PASSWORD_ERROR_MESSAGE,
  REQUIRED_MESSAGE,
} from "../../../Constant/Constant";

const AdminSetting = () => {
  const { t } = useTranslation();
  const [selectedLanguage, setSelectedLanguage] = useState(null);
  const options = [{ name: "english" }, { name: "chinese" }];
  const [showPassword, setShowPassword] = useState({
    current_password: false,
    new_password: false,
  });
  const passwordSchema = yup.object().shape({
    new_password: yup.string().required(t(REQUIRED_MESSAGE)),
    current_password: yup
      .string()
      .required(t(REQUIRED_MESSAGE))
      .test("not-equal", t(PASSWORD_ERROR_MESSAGE), function (value) {
        const { new_password } = this.parent;
        return value !== new_password;
      }),
  });
  const languageSchema = yup.object().shape({
    selectedLanguage: yup.string().required(t(REQUIRED_MESSAGE)),
  });
  const {
    register,
    control,
    setError,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(passwordSchema),
  });

  const {
    register: languageRegister,
    handleSubmit: handleLanguageSubmit,
    formState: { errors: languageErrors },
  } = useForm({
    resolver: yupResolver(languageSchema),
  });
  const handleChangePassword = (type, value) => {
    const current_password = watch("current_password");
    const new_password = watch("new_password");
    if (type === "new_password") {
      if (value === current_password) {
        if (current_password?.length) {
          setError("current_password", {
            type: "manual",
            message: t(PASSWORD_ERROR_MESSAGE),
          });
        }
      } else {
        setError("current_password", { type: "manual", message: "" });
      }
    }
  };
  const languageSubmit = (data) => {};
  const onSubmit = (data) => {};
  return (
    <div>
      <form onSubmit={handleLanguageSubmit(languageSubmit)}>
        <AdminHeaderSection heading={t("setting")} showFilter={false} />
        {/* language */}
        <FormControl>
          <FormLabel>{t("select_language")}</FormLabel>
          <Select
            className="formInputFiled mb-4"
            placeholder="Please Select"
            {...languageRegister("selectedLanguage")}
          >
            {options?.map((menu, index) => (
              <MenuItem value={menu.name} key={index}>
                {menu.name}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <Button
          type="submit"
          className="arrowButton"
          variant="contained"
          color="primary"
        >
          {t("save")}
        </Button>
      </form>

      {languageErrors?.selectedLanguage && (
        <ErrorMessage msg={languageErrors?.selectedLanguage.message} />
      )}
      {/* <SelectWithController name = "selectedLanguage" options ={option}/> */}

      {/* password */}
      <form onSubmit={handleSubmit(onSubmit)}>
        <Box
          display="flex"
          alignItems="center"
          mb={2}
          className="passwordinput"
        >
          <Controller
            name="new_password"
            control={control}
            defaultValue=""
            render={({ field }) => (
              <CustomTextField
                {...field}
                onChange={(e) => {
                  handleChangePassword("new_password", e.target.value);
                  field.onChange(e);
                }}
                className="formInputFiled passField"
                // placeholder={t("password")}
                placeholder={t("new_password")}
                autoComplete="current-password"
                type={showPassword?.new_password ? "text" : "password"}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        onClick={() =>
                          setShowPassword({
                            ...showPassword,
                            new_password: !showPassword?.new_password,
                          })
                        }
                      >
                        {showPassword?.new_password ? (
                          <VisibilityOffIcon />
                        ) : (
                          <VisibilityIcon />
                        )}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            )}
          />
          {errors.new_password && (
            <ErrorMessage msg={errors.new_password.message} />
          )}
          <Controller
            name="current_password"
            control={control}
            defaultValue=""
            render={({ field }) => (
              <CustomTextField
                {...field}
                onChange={(e) => {
                  handleChangePassword("current_password", e.target.value);
                  field.onChange(e);
                }}
                className="formInputFiled passField"
                placeholder={t("current_password")}
                autoComplete="current-password"
                type={showPassword?.current_password ? "text" : "password"}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        onClick={() =>
                          setShowPassword({
                            ...showPassword,
                            current_password: !showPassword?.current_password,
                          })
                        }
                      >
                        {showPassword?.current_password ? (
                          <VisibilityOffIcon />
                        ) : (
                          <VisibilityIcon />
                        )}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            )}
          />
          {errors.current_password && (
            <ErrorMessage msg={errors.current_password.message} />
          )}
        </Box>
        <Button
          type="submit"
          className="arrowButton"
          variant="contained"
          color="primary"
        >
          {t("save_password")}
        </Button>
      </form>
    </div>
  );
};

export default AdminSetting;
