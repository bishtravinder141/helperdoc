import React from "react";
import { AGENCY_LIST_LIMIT } from "../constant";
import { Visibility } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";

const SingleAgencyTableRow = ({ rowData, index, currentPage,setShowVerificationModal }) => {
  const navigate = useNavigate();
  const { email, phoneNumber, fullName , userId } = rowData;
  return (
    <tr>
      <td>
        <div>
          <span className="strong">
            #{(currentPage - 1) * AGENCY_LIST_LIMIT + index + 1}
          </span>
        </div>
      </td>
      <td>
        <div>
          <span className="strong">{fullName}</span>
        </div>
      </td>
      <td>
        <div>
          <span className="strong">{email}</span>
        </div>
      </td>
      <td>
        <div>
          <span className="strong">{phoneNumber}</span>
        </div>
      </td>
      <td>
        <div>
          <span className="strong">Invoice</span>
        </div>
      </td>
      <td>
        <div>
          <span className="strong">Employer plan</span>
        </div>
      </td>
      <td>
        <div>
          <span className="strong">Active</span>
        </div>
      </td>
      <td>
        <div
          className="cursor-pointer"
          onClick={() => {
            navigate(`/admin/agency-detail/${userId}`);
          }}
        >
          <Visibility />
        </div>
      </td>
    </tr>
  );
};

export default SingleAgencyTableRow;
