import React from 'react'

const SingleTransactionTableRow = () => {
  return (
    <div>SingleTransactionTableRow</div>
  )
}

export default SingleTransactionTableRow