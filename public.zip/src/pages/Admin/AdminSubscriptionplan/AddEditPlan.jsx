import React from "react";

const AddEditPlan = () => {
  return (
    <>
      <Box
        className="profileCardBox"
        border={1}
        borderRadius={8}
        borderColor="#e7e7e7"
        py={6}
        px={10}
        mb={2}
        mt={2}
      >
        
      </Box>
    </>
  );
};

export default AddEditPlan;
